# Security policy

Do not disclose a suspected fund-loss, consensus-divergence, recovery, signing, key, or protected-UTXO vulnerability in a public issue before maintainers acknowledge a private report.

Send a minimal report to the private security contact published in the repository security settings. Include affected commit, network, transaction or PSBT bytes where safe, expected behavior, observed behavior, and a reproducible test. Never include seed phrases, private keys, production credentials, or personally identifying wallet data.

Mainnet construction and broadcast remain disabled until the launch gate ledger is green and explicit activation authority exists.
